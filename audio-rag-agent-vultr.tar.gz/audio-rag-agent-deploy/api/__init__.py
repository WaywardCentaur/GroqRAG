"""
API package for the Real-Time Audio RAG Agent.
"""
